'use strict';

exports.handler = function (event, context, callback) {
    var response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'text/xml; charset=utf-8',
        },
        body: "This is the dummy lambda payload for EhrExtractHandler",
    };
    callback(null, response);
};
