exports.handler = async (event, context, callback) => {
    let response = {
        "statusCode": 200,
        "body": "This is the dummy lambda payload for RetrieveStatus",
        "isBase64Encoded": false
    };

    callback(null, response);
};
